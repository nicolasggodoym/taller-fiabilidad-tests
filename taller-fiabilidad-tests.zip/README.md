# taller-fiabilidad-tests
 Repositorio creado para el taller de análisis de ítems y confiabilidad para test psicológicos, en el marco del curso Instrumentos para la medición psicológica dictado por la profesora Claudia Zúñiga.
